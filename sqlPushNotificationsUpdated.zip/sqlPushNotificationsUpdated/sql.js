import * as SQLite from 'expo-sqlite';

let db

export const init = async () => {
  console.log('Initializing database . . .')
  try {
    db = await SQLite.openDatabaseAsync('mySqlDb.db')
    console.log('openDatabaseAsync done')
    await db.execAsync(
      'CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY NOT NULL, title TEXT NOT NULL);',
      [] // An array of data that can be inserted into the sql query, not used here
    )
    console.log('Initialized database')
  } catch (err) {
    console.log('Initialized database failed: ' + err)
  }
}

export const insertItem = async (newItem) => {
  try {
    const result = await db.runAsync('INSERT INTO items (title) VALUES (?)', newItem.title)
  //  const result = await db.execAsync(
  //    `INSERT INTO items (title) VALUES ('` + newItem.title + `');`
  //  )
    console.log('insertItem result: ' + JSON.stringify(result))
    return result
  } catch (err) {
    console.log('insertItem failed: ' + err)
    return err
  }
}

export const fetchItems = async () => {
  try {
    const result = await db.getAllAsync('SELECT * FROM items')
  //  const result = await db.execAsync(
   //   'SELECT * FROM items', // could add WHERE etc. 
   //     [],  // An array of data that can be inserted into the sql query, not used here
  //  )
  console.log('fetchItems result: ' + JSON.stringify(result))

  for (const row of result) {
    console.log(row.id, row.title);
  }
     return result
  } catch (err) {
    console.log('fetchItems failed: ' + err)
    return err
  }
}
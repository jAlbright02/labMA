import * as SQLite from 'expo-sqlite';

let db

export const init = async () => {
  console.log('Initializing database . . .')
  try {
    db = await SQLite.openDatabaseAsync('mysqldb.db')
    console.log('openDatabaseAsync done')
    await db.execAsync(
      'CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, price REAL);',
      [] // An array of data that can be inserted into the sql query, not used here
    )
    console.log('Initialized database')
  } catch (err) {
    console.log('Initialized database failed: ' + err)
  }
}

export const insertItem = async (newItem) => {
  try {
    const result = await db.runAsync(
      'INSERT INTO items (title, price) VALUES (?, ?)', 
      newItem.title,
      newItem.price  
    );

    console.log('insertItem result: ' + JSON.stringify(result))
    return result
  } catch (err) {
    console.log('insertItem failed: ' + err)
    return err
  }
}

export const fetchItems = async () => {
  if (!db) {
    console.log('Database not initialised');
    return [];
  }
  try {
    const result = await db.getAllAsync('SELECT * FROM items')
  console.log('fetchItems result: ' + JSON.stringify(result))

  for (const row of result) {
    console.log(row.id, row.title, row.price);
  }
     return result
  } catch (err) {
    console.log('fetchItems failed: ' + err)
    return []
  }
}

export const deleteItemById = async (itemId) => {
  try {
    const result = await db.runAsync('DELETE FROM items WHERE id = ?', itemId);
    console.log('deleteItemById result: ' + JSON.stringify(result));
    return result;
  } catch (err) {
    console.log('deleteItemById failed: ' + err);
    return err;
  }
};
// import * as React from 'react';
import { NavigationContainer, useFocusEffect } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { StyleSheet, Button, Text, View, Alert, Platform, FlatList, Pressable } from 'react-native'
import React, { useState, useEffect } from 'react'
import * as Notifications from 'expo-notifications'
import Constants from 'expo-constants'
import { init, insertItem, fetchItems } from './sql'

const Stack = createNativeStackNavigator()

Notifications.setNotificationHandler({
  handleNotification: async () => {
    return {
      shouldPlaySound: false,
      shouldSetBadge: false,
      shouldShowAlert: true
    };
  }
});

export default App = () => {
  useEffect(() => {
    init()
      .then(() => {
        console.log('Initialized database');
      })
      .catch(err => {
        console.log('Initializing db failed.');
        console.log(err);
      })

    async function configurePushNotifications() {
      const { status } = await Notifications.getPermissionsAsync();
      let finalStatus = status;

      if (finalStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        Alert.alert(
          'Permission required',
          'Push notifications need the appropriate permissions.'
        );
        return;
      }

      // https://expo.dev/accounts/[ACCOUNT_NAME]/projects. Select your project and at the top of the overview page you should see your project id.
      let pushTokenData = await Notifications.getExpoPushTokenAsync({ projectId: '9378ba48-7566-42f4-9b70-026ad3c5a482' })
      pushTokenData = pushTokenData.data
      console.log(JSON.stringify(pushTokenData));

      if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
          name: 'default',
          importance: Notifications.AndroidImportance.DEFAULT,
        });
      }
    }

    configurePushNotifications()
  }, [])

  // function scheduleNotificationHandler() {
  //   Notifications.scheduleNotificationAsync({
  //     content: {
  //       title: 'My first local notification',
  //       body: 'This is the body of the notification.',
  //       data: { userName: 'Max' }
  //     },
  //     trigger: {
  //       type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
  //       seconds: 5
  //     }
  //   });
  // }

  async function sendPushNotificationHandler() {
    let resp = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to: 'ExponentPushToken[XFeZ68DN8iGrl6NcDlLPzp]',
        title: 'Test - push notification sent from a device!',
        body: 'This is a push notification test!'
      })
    });
    resp = await resp.json()
    console.log('JSON.stringify(resp): ' + JSON.stringify(resp))
  }

  return (
    // <View style={styles.container}>
    //   <Button
    //     title="Send Push Notification"
    //     onPress={sendPushNotificationHandler}
    //   />
    //   <Button
    //     title="Add Item to DB "
    //     onPress={addItemToDb}
    //   />
    //   <Button
    //     title="List DB Items"
    //     onPress={listItemsInDb}
    //   />
    //   <StatusBar style="auto" />
    // </View>
    
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Home' }}
        />
        <Stack.Screen
          name="AddProductView"
          component={AddProductView}
          options={{ title: 'Add Product' }}
        /> 
      </Stack.Navigator>
    </NavigationContainer>
    
  )
}

async function addItemToDb() {
  await insertItem({ title: 'theTitle' })
}
async function listItemsInDb() {
  try {
    let theItems = await fetchItems()
    console.log('listItemsInDb: ' + JSON.stringify(theItems))
    return JSON.stringify(theItems);
  } catch (error) {
    console.log(error);
  }
}

const HomeScreen = ({ navigation }) => {

  const [items, setItems] = useState([]);
  let prods = [{"id": 1}, {"id": 2}, {"id": 3}]

  const getItems = async () => {
    const fetchedItems = await listItemsInDb();
    setItems(fetchedItems)
  }

  useFocusEffect(
    React.useCallback(() => {
      getItems();
    }, [])
  );

  console.log('items here: ', items)

  return (
    <View>
    <Text>Items</Text>
    <FlatList
      data={items}
      keyExtractor={(item) => item._id}
      renderItem={({ item }) => (
        <Pressable
          // onPress={() =>
          //   navigation.navigate('EditProductView', {
          //     ourId: item.ourId,
          //     name: item.name,    
          //     price: item.price,   
          //   })
          // }
        >
          <View style={{ padding: 10, marginVertical: 5, backgroundColor: '#f0f0f0', borderRadius: 5 }}>
            <Text>{item.name}</Text>
          </View>
        </Pressable>
      )}
    />
    <Text>Click a product to edit</Text>
    <Button title='List All' onPress={listItemsInDb}></Button>
    <Button title='Add a product' onPress={() => navigation.navigate('AddProductView')} />
    </View>
  )
}

const AddProductView = ({ navigation }) => {
  const [productData, setProductData] = useState({name: '', price: ''})
  const addProduct = async () => {
    try {
      const res = await fetch(
        `${ngrokURL}/addProduct`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            "ngrok-skip-browser-warning": "69420" // See: https://stackoverflow.com/questions/73017353/how-to-bypass-ngrok-browser-warning
          },
          body: JSON.stringify({
            name: productData.name,
            price: productData.price,
          }),
        }
      )
      const data = await res.json()
      if (data.success) {
        console.log('Product added successfully');
        navigation.navigate('ProductView');
      } else {
        console.log('Error occurred during update');
      }
    } catch (err) {
      console.log(err)
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Add Product</Text>

      <Text>Product Name:</Text>
      <TextInput
        style={{
          borderWidth: 1,
          padding: 8,
          marginBottom: 10,
          borderRadius: 5,
        }}
        onChangeText={(text) => setProductData({ ...productData, name: text })}
      />

      <Text>Product Price:</Text>
      <TextInput
        style={{
          borderWidth: 1,
          padding: 8,
          marginBottom: 20,
          borderRadius: 5,
        }}
        onChangeText={(text) => setProductData({ ...productData, price: text })}
        keyboardType="numeric"
      />

      <Button title="Save Changes" onPress={addProduct} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

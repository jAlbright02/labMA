// import * as React from 'react';
import { NavigationContainer, useFocusEffect } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { StyleSheet, Button, Text, View, Alert, Platform, FlatList, Pressable, TextInput } from 'react-native'
import React, { useState, useEffect } from 'react'
import * as Notifications from 'expo-notifications'
import Constants from 'expo-constants'
import { init, insertItem, fetchItems, deleteItemById } from './sql'

const Stack = createNativeStackNavigator()

Notifications.setNotificationHandler({
  handleNotification: async () => {
    return {
      shouldPlaySound: false,
      shouldSetBadge: false,
      shouldShowAlert: true
    };
  }
});

export default App = () => {
  useEffect(() => {
    init()
      .then(() => {
        console.log('Initialized database');
      })
      .catch(err => {
        console.log('Initializing db failed.');
        console.log(err);
      })

    async function configurePushNotifications() {
      const { status } = await Notifications.getPermissionsAsync();
      let finalStatus = status;

      if (finalStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        Alert.alert(
          'Permission required',
          'Push notifications need the appropriate permissions.'
        );
        return;
      }

      // https://expo.dev/accounts/[ACCOUNT_NAME]/projects. Select your project and at the top of the overview page you should see your project id.
      let pushTokenData = await Notifications.getExpoPushTokenAsync({ projectId: '9378ba48-7566-42f4-9b70-026ad3c5a482' })
      pushTokenData = pushTokenData.data
      console.log(JSON.stringify(pushTokenData));

      if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
          name: 'default',
          importance: Notifications.AndroidImportance.DEFAULT,
        });
      }
    }

    configurePushNotifications()
  }, [])

  async function sendPushNotificationHandler() {
    let resp = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to: 'ExponentPushToken[XFeZ68DN8iGrl6NcDlLPzp]',
        title: 'Test - push notification sent from a device!',
        body: 'This is a push notification test!'
      })
    });
    resp = await resp.json()
    console.log('JSON.stringify(resp): ' + JSON.stringify(resp))
  }

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Home' }}
        />
        <Stack.Screen
          name="AddProductView"
          component={AddProductView}
          options={{ title: 'Add Product' }}
        /> 
      </Stack.Navigator>
    </NavigationContainer>
    
  )
}

async function sendLocalNotification(action, item) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `${action}`,
      body: `You Have ${action} ${item.title} that has a price of ${item.price}`,
    },
    trigger: { seconds: 1 }, // Show the notification after 1 second
  });

  await sendPushNotificationHandler(action, item);
};

async function sendPushNotificationHandler(action, item) {
  let resp = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      to: 'ExponentPushToken[XFeZ68DN8iGrl6NcDlLPzp]',
      title: `Action: ${action}`,
      body: `Item that was ${action}: ${item}`
    })
  });
  resp = await resp.json()
  console.log('JSON.stringify(resp): ' + JSON.stringify(resp))
}

async function deleteItem(item) {
  sendLocalNotification('Deleted', item)
  await deleteItemById(item.id);
}

async function addItemToDb(item) {
  await insertItem({ title: item.title, price: item.price })
  sendLocalNotification('Added', item)
}
async function listItemsInDb() {
  try {
    const theItems = await fetchItems()
    console.log('listItemsInDb: ' + JSON.stringify(theItems))
    return theItems;
  } catch (error) {
    console.log(error);
  }
}

const HomeScreen = ({ navigation }) => {

  const [items, setItems] = useState([]);

  const getItems = async () => {
    const fetchedItems = await listItemsInDb();
    setItems(fetchedItems)
  }

  useFocusEffect(
    React.useCallback(() => {
      getItems();
    }, [])
  )

  console.log('items here: ', items)

  return (
    <View>
      <Text style={{fontSize: 20, textAlign: 'center'}}>Items</Text>
      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ padding: 10, marginVertical: 5, backgroundColor: '#f0f0f0', borderRadius: 5 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View>
                <Text>{item.title}</Text>
                <Text>Price: {item.price}</Text>
              </View>
              <Button
                title="Delete"
                onPress={() => {deleteItem(item); getItems()}} // Pass the item's id to deleteItem
              />
            </View>
          </View>
        )}
      />
      <Button title='List All' onPress={getItems} />
      <Button title='Add a product' onPress={() => navigation.navigate('AddProductView')} />
    </View>
  );
}

const AddProductView = ({ navigation }) => {
  const [item, setItem] = useState({ title: '', price: '' });

  const addProduct = async () => {
    try {
      await addItemToDb(item);
      console.log('Product added successfully');
      navigation.navigate('Home');
    } catch (err) {
      console.log('Error adding product:', err);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Add Item</Text>

      <Text>Item Name:</Text>
      <TextInput
        style={{
          borderWidth: 1,
          padding: 8,
          marginBottom: 10,
          borderRadius: 5,
        }}
        onChangeText={(text) => setItem({ ...item, title: text })}
      />

      <Text>Item Price:</Text>
      <TextInput
        style={{
          borderWidth: 1,
          padding: 8,
          marginBottom: 20,
          borderRadius: 5,
        }}
        onChangeText={(text) => setItem({ ...item, price: text })}
        keyboardType="numeric"
      />

      <Button title="Save Item" onPress={addProduct} />
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
